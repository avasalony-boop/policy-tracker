from datetime import datetime
from typing import Dict, Any, List
from effective_date import extract_effective_date

CLASSIFY_MAP = {
    "introduced": "INTRODUCED",
    "referral": "IN_COMMITTEE",
    "committee-referral": "IN_COMMITTEE",
    "committee-passage": "REPORTED",
    "committee-passage-favorable": "REPORTED",
    "reading-1": "ON_FLOOR",
    "reading-2": "ON_FLOOR",
    "reading-3": "ON_FLOOR",
    "floor-passage": "ON_FLOOR",
    "passage": "PASSED_CHAMBER",
    "executive-signature": "ENACTED",
    "enacted": "ENACTED",
    "chaptered": "ENACTED",
    "veto": "VETOED",
}

def derive_status_general(actions: List[Dict[str, Any]]) -> str:
    seen = set()
    last = "INTRODUCED"
    for a in sorted(actions, key=lambda x: x.get("action_date","") or ""):
        for c in a.get("classification", []):
            mapped = CLASSIFY_MAP.get(c)
            if not mapped:
                continue
            if mapped == "PASSED_CHAMBER":
                seen.add(mapped)
                # crude check: if we have 2 'passage' classifications overall, treat as passed legislature
                if "PASSED_CHAMBER" in seen and sum(1 for s in actions if "passage" in (s.get("classification") or [])) >= 2:
                    last = "PASSED_LEGISLATURE"
            else:
                last = mapped
    return last

def normalize_openstates_bill(b: Dict[str, Any]) -> Dict[str, Any]:
    bill_uid = f"openstates:{b['id']}"
    jurisdiction = b.get("jurisdiction", {}).get("name")
    session = b.get("from_session")
    bill_number = b.get("identifier")
    title = b.get("title")
    summary = b.get("summary")
    subjects = ",".join(b.get("subject", []) or [])
    sponsors = b.get("sponsorships", [])
    sponsor_primary = ""
    for s in sponsors:
        if s.get("primary"):
            sponsor_primary = s.get("name") or (s.get("person") or {}).get("name") or ""
            break
    committees = []
    actions_norm = []
    for a in b.get("actions", []):
        org = (a.get("organization") or {}).get("name") or ""
        if org and org not in committees:
            committees.append(org)
        actions_norm.append({
            "action_date": a.get("date"),
            "organization": org,
            "classification": a.get("classification", []),
            "action_text": a.get("description")
        })
    status_general = derive_status_general(actions_norm) if actions_norm else "INTRODUCED"
    introduced_date = b.get("first_action_date") or None
    last_action_date = b.get("latest_action_date") or (actions_norm[-1]["action_date"] if actions_norm else None)
    effective_date = extract_effective_date(actions_norm)

    return {
        "bill": {
            "bill_uid": bill_uid,
            "source": "openstates",
            "jurisdiction": jurisdiction,
            "session": session,
            "bill_number": bill_number,
            "title": title,
            "summary": summary,
            "subjects": subjects,
            "sponsors_primary": sponsor_primary,
            "committees": ",".join(committees[:10]),
            "status_general": status_general,
            "status_specific": "",
            "introduced_date": introduced_date,
            "effective_date": effective_date,
            "last_action_date": last_action_date,
            "updated_at": datetime.utcnow().isoformat()
        },
        "actions": actions_norm
    }
