# Patch Guide — Apply to your repo

This patch adds:
- **All-states support** (collector only sends `jurisdiction` when a state is provided)
- **Effective Date parsing** (from action text like "effective July 1, 2026" or "effective immediately")
- A **.gitignore** so `.env` and local DB don’t get committed

## Files included
- `.gitignore` (new)
- `effective_date.py` (new)
- `collector.py` (replace your file with this one)
- `normalize.py` (replace your file with this one)

## How to apply (GitHub web UI — simplest)
1. Open your repo on GitHub.
2. Navigate to the root folder and click **Add file → Upload files**.
3. Drag the four files from this zip into the upload area.
4. When GitHub warns files with the same name will be replaced, click **Commit changes**.

## How to apply (local + git)
```sh
# In your local clone
unzip policy_tracker_patch.zip -d /tmp/policy_tracker_patch
cd /path/to/your/local/repo

# Copy files over the existing ones
cp /tmp/policy_tracker_patch/.gitignore .
cp /tmp/policy_tracker_patch/effective_date.py .
cp /tmp/policy_tracker_patch/collector.py .
cp /tmp/policy_tracker_patch/normalize.py .

git add .
git commit -m "Add effective date parsing and all-states support; add .gitignore"
git push
```

## After applying
1. Ensure your `.env` is present locally (never commit it) and has your real keys.
2. Re-run migrations (safe to repeat):
```sh
python db.py migrate
```
3. Test a pull (single state):
```sh
python collector.py --since 2025-09-01 --state=CA --q "artificial intelligence OR generative"
```
4. Test **all-states** (leave DEFAULT_STATES empty in `.env` and run):
```sh
python collector.py
```
5. Start the dashboard:
```sh
uvicorn serve:app --reload
```
Open http://127.0.0.1:8000
