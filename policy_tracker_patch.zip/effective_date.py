from datetime import datetime
import re
from typing import List, Dict, Any, Optional

MONTHS = {
    "january":1,"february":2,"march":3,"april":4,"may":5,"june":6,
    "july":7,"august":8,"september":9,"october":10,"november":11,"december":12
}

DATE_PATTERNS = [
    # "effective July 1, 2026"
    re.compile(r"(effective|takes effect|take effect|shall take effect|becomes effective|effective on)\s+(?:on\s+)?([A-Za-z]+)\s+(\d{1,2}),\s*(\d{4})", re.IGNORECASE),
    # "effective 7/1/2026" or "effective on 07-01-2026"
    re.compile(r"(effective|takes effect|take effect|shall take effect|effective on)\s+(?:on\s+)?(\d{1,2})[\/-](\d{1,2})[\/-](\d{2,4})", re.IGNORECASE),
    # "effective January 2026" (assume first of month)
    re.compile(r"(effective|takes effect|take effect|shall take effect|effective on)\s+(?:on\s+)?([A-Za-z]+)\s+(\d{4})", re.IGNORECASE),
]

IMMEDIATE_PATTERNS = [
    re.compile(r"effective immediately", re.IGNORECASE),
    re.compile(r"take[s]? effect immediately", re.IGNORECASE),
]

def _parse_year(y):
    year = int(y)
    if year < 100:
        year += 2000
    return year

def extract_effective_date(actions: List[Dict[str, Any]], fallback_signature_date: Optional[str]=None) -> Optional[str]:
    texts = []
    enacted_date = None
    for a in actions or []:
        desc = a.get("action_text") or ""
        texts.append(desc)
        cls = a.get("classification") or []
        if any(c in ("executive-signature","enacted","chaptered") for c in cls):
            enacted_date = a.get("action_date")

    if fallback_signature_date:
        enacted_date = fallback_signature_date or enacted_date

    for t in texts:
        if any(p.search(t) for p in IMMEDIATE_PATTERNS):
            return enacted_date

    for t in texts:
        for pat in DATE_PATTERNS:
            m = pat.search(t)
            if not m:
                continue
            g = m.groups()
            # Month Day, Year
            if len(g) == 4 and g[1].isalpha():
                month_name = g[1].lower()
                month = MONTHS.get(month_name)
                day = int(g[2])
                year = int(g[3])
                if month:
                    return f"{year:04d}-{month:02d}-{day:02d}"
            # mm/dd/yyyy or mm-dd-yyyy
            if len(g) == 4 and not g[1].isalpha():
                mm, dd, yy = int(g[1]), int(g[2]), _parse_year(g[3])
                return f"{yy:04d}-{mm:02d}-{dd:02d}"
            # Month Year (assume 1st)
            if len(g) == 3 and g[1].isalpha():
                month = MONTHS.get(g[1].lower())
                year = int(g[2])
                if month:
                    return f"{year:04d}-{month:02d}-01"
    return None
